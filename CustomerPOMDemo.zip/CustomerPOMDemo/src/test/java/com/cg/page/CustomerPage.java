package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CustomerPage {
	
	private WebDriver driver;
	
	@FindBy(how = How.ID,using = "cname")
	@CacheLookup
	private WebElement cusName;
	
	@FindBy(how = How.ID,using = "add")
	@CacheLookup
	private WebElement address;
	
	@FindBy(how =How.ID,using = "no")
	@CacheLookup
	private WebElement contactNo;
	
	@FindBy(how = How.ID,using = "porder")
	@CacheLookup
	private WebElement placeOrderBtn;
	
	@FindBy(how = How.LINK_TEXT,using = "Help")
	private WebElement helpLink;

	public CustomerPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName.sendKeys(cusName);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo.clear();
		this.contactNo.sendKeys(contactNo);
	}
	
	public void placeOrderBtn() {
		placeOrderBtn.click();
	}
	
	public void helpclick() {
		helpLink.click();
	}
	
}
