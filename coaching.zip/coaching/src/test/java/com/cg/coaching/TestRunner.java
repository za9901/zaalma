package com.cg.coaching;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\mirza\\OneDrive\\Desktop\\coaching\\src\\test\\java\\com\\cg\\coaching\\feature\\CoachingForm.feature", glue = "com.cg.coaching.stepDef", plugin = {
		"pretty", "html:target/coachingform-report" }, monochrome = true/*,tags="@smokeTest"*/)
public class TestRunner {

}
