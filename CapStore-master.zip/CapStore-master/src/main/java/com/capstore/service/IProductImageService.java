package com.capstore.service;

import java.util.List;

import com.capstore.model.ProductImage;

public interface IProductImageService {

	public List<ProductImage> getimages();
	
}
